package com.example.stockprototype;

import android.app.Application;

import com.example.stockprototype.Modelos.Pantalon;
import com.example.stockprototype.Modelos.PedidoMaterialTextil;
import com.example.stockprototype.Modelos.PrendaVestir;
import com.example.stockprototype.Modelos.ProveedorMaterialTextil;
import com.example.stockprototype.Modelos.Sudadera;
import com.parse.Parse;
import com.parse.ParseObject;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PrendaProveedoresPedidosApplication extends Application {

    public List<PrendaVestir> prendaVestirList = new ArrayList<>();
    public List<ProveedorMaterialTextil> proveedorMaterialTextilList = new ArrayList<>();
    public List<PedidoMaterialTextil> pedidoMaterialTextilList = new ArrayList<>();
    public List<Pantalon> listaPantalones = new ArrayList<>();
    public List<Sudadera> listaSudaderas = new ArrayList<>();
    private int positionPrendaVestirList = 0;


    private int positionPantalonList = 0;
    private int tipo;
    private int positionProveedorMaterialTextilList = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        rellenarProveedorMaterialTextilList();
        ParseObject.registerSubclass(Sudadera.class);
        ParseObject.registerSubclass(Pantalon.class);

        Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId("myAppId") //si no has cambiado APP_ID, sino pon el valor de APP_ID
                .clientKey("empty")
                .server("https://alvarolarraya.herokuapp.com/parse")   // '/' important after 'parse'
                .build());
    }
    public List<PrendaVestir> getPrendasVestirDatabase(){
        List<PrendaVestir> prendaVestirListDatabase = new ArrayList<>();
        return prendaVestirListDatabase;
    }
    public void addPrendaVestir(PrendaVestir prendaVestir){
        prendaVestirList.add(prendaVestir);
    }
    public void addProveedorMaterialTextil(ProveedorMaterialTextil proveedorMaterialTextil){
        proveedorMaterialTextilList.add(proveedorMaterialTextil);
    }
    public void modifyPrendaVestirList(int position, PrendaVestir prendaVestir){
        PrendaVestir prendaAModificar = prendaVestirList.get(position);
        prendaAModificar.setID(prendaVestir.getID());
        prendaAModificar.setTipoPrenda(prendaVestir.getTipoPrenda());
        prendaAModificar.setTalla(prendaVestir.getTalla());
        prendaAModificar.asociarProveedores(proveedorMaterialTextilList);
        List<Integer> toBeRemoved = new ArrayList<>();
        for(int i = pedidoMaterialTextilList.size() - 1; i >=0;  i--){
            if(pedidoMaterialTextilList.get(i).getIdPrenda() == prendaVestir.getID()){
                pedidoMaterialTextilList.remove(i);
            }
        }
        System.out.println(pedidoMaterialTextilList.size());
        crearPedidos(prendaAModificar);
    }
    public void modifyProveedorMaterialTextilList(int position, ProveedorMaterialTextil proveedorMaterialTextil){
        ProveedorMaterialTextil proveedorAModificar = proveedorMaterialTextilList.get(position);
        proveedorAModificar.setMaterialTextil(proveedorMaterialTextil.getMaterialTextil());
        proveedorAModificar.setDireccion(proveedorMaterialTextil.getDireccion());
        proveedorAModificar.setNombre(proveedorMaterialTextil.getNombre());
        proveedorAModificar.setCIF(proveedorMaterialTextil.getCIF());
    }

    public void setPositionPrendaVestirList(int position){
        this.positionPrendaVestirList = position;
    }
    public void setPositionProveedorMaterialTextilList(int positionProveedorMaterialTextilList) {
        this.positionProveedorMaterialTextilList = positionProveedorMaterialTextilList;
    }
    public void crearPedidos(PrendaVestir prenda){
        for (ProveedorMaterialTextil proveedor: prenda.getListaProveedoresAsociados()){
            PedidoMaterialTextil pedido = new PedidoMaterialTextil(proveedor, proveedor.getMaterialTextil(), prenda.getID());
            pedidoMaterialTextilList.add(pedido);
        }
    }
    public int getPositionPrendaVestirList() {
        return positionPrendaVestirList;
    }

    public int getPositionProveedorMaterialTextilList() {
        return positionProveedorMaterialTextilList;
    }
    public void rellenarProveedorMaterialTextilList(){
        ProveedorMaterialTextil proveedorMaterialTextil = new ProveedorMaterialTextil("Proveedor Hilo",
                "A12345678", "C/Falsa 123", "Hilo");
        proveedorMaterialTextilList.add(proveedorMaterialTextil);
        proveedorMaterialTextil = new ProveedorMaterialTextil("Proveedor Seda",
                "A12354678", "C/Falsa 132", "Seda");
        proveedorMaterialTextilList.add(proveedorMaterialTextil);
        proveedorMaterialTextil = new ProveedorMaterialTextil("Proveedor Algodón",
                "A82354671", "C/Falsa 312", "Algodón");
        proveedorMaterialTextilList.add(proveedorMaterialTextil);
        proveedorMaterialTextil = new ProveedorMaterialTextil("Proveedor Lino",
                "A83254671", "C/Falsa 321", "Lino");
        proveedorMaterialTextilList.add(proveedorMaterialTextil);
        proveedorMaterialTextil = new ProveedorMaterialTextil("Proveedor Botones",
                "A82654371", "C/Falsa 213", "Botones");
        proveedorMaterialTextilList.add(proveedorMaterialTextil);
    }

    public int getPositionPantalonList() {
        return positionPantalonList;
    }

    public void setPositionPantalonList(int positionPantalonList) {
        this.positionPantalonList = positionPantalonList;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }
}
