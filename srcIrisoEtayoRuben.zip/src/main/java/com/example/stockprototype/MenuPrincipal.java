package com.example.stockprototype;

import android.content.Intent;
import android.os.Bundle;

import com.example.stockprototype.databinding.ActivityMenuPrincipalBinding;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;

public class MenuPrincipal extends AppCompatActivity {

    private ActivityMenuPrincipalBinding binding;
    PrendaProveedoresPedidosApplication ppa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMenuPrincipalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolBarLayout = binding.toolbarLayout;
        toolBarLayout.setTitle(getTitle());

        ppa = (PrendaProveedoresPedidosApplication)getApplicationContext();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){
            case (R.id.anadir_prenda):
                Intent intentAnadirPrenda = new Intent(getApplicationContext(),
                        AnadirPrendaActivity.class);
                startActivityForResult(intentAnadirPrenda, 1);
                break;
            case (R.id.anadir_proveedor):
                Intent intentAnadirProveedor = new Intent(getApplicationContext(),
                        AnadirProveedorActivity.class);
                startActivityForResult(intentAnadirProveedor, 2);
                break;
            case(R.id.listar_prendas):
                if (ppa.prendaVestirList.size() > 0) {
                    Intent intentListadoPrendas = new Intent(getApplicationContext(),
                            ListadoPrendasActivity.class);
                    startActivityForResult(intentListadoPrendas, 4);
                }
                else{
                    Snackbar.make(findViewById(android.R.id.content)
                            , "No hay prendas", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
                break;
            case(R.id.listar_proveedores):
                if (ppa.proveedorMaterialTextilList.size() > 0) {
                    Intent intentListadoProveedores = new Intent(getApplicationContext(),
                            ListadoProveedoresActivity.class);
                    startActivityForResult(intentListadoProveedores, 5);
                }
                else{
                    Snackbar.make(findViewById(android.R.id.content)
                            , "No hay proveedores", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
                break;
            case(R.id.listar_pedidos):
                if (ppa.pedidoMaterialTextilList.size() > 0) {
                    Intent intentMostrarPedidos = new Intent(getApplicationContext(),
                            ListadoPedidosActivity.class);
                    startActivityForResult(intentMostrarPedidos, 5);
                }
                else{
                    Snackbar.make(findViewById(android.R.id.content)
                            , "No hay pedidos", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
                break;
            case(R.id.listar_sudaderas_database):
                Intent intentListarPrendasDatabase = new Intent(getApplicationContext(),
                ListarSudaderasDatabaseActivity.class);
                startActivityForResult(intentListarPrendasDatabase, 6);
                break;
            case(R.id.listar_pantalones_database):
                Intent intentListarPantalonesDatabase = new Intent(getApplicationContext(),
                        ListarPantalonesDatabaseActivity.class);
                startActivityForResult(intentListarPantalonesDatabase, 7);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

    }
}