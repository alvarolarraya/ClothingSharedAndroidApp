package com.example.stockprototype;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.stockprototype.Modelos.PrendaVestir;
import com.example.stockprototype.Modelos.Sudadera;
import com.example.stockprototype.databinding.ActivityListarSudaderasDatabaseBinding;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseQuery;

import java.util.List;

public class ListarSudaderasDatabaseActivity extends AppCompatActivity {

    private ActivityListarSudaderasDatabaseBinding binding;
    private PrendaProveedoresPedidosApplication ppa;
    ListView listView;
    ArrayAdapter<PrendaVestir> prendaVestirArrayAdapter;
    ArrayAdapter<Sudadera> sudaderasArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityListarSudaderasDatabaseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();

        listView = findViewById(R.id.listaSudaderasDatabase);
        sudaderasArrayAdapter = new ArrayAdapter<Sudadera>(this, R.layout.item_view_ver_foto, R.id.listText, ppa.listaSudaderas);

        listView.setAdapter(sudaderasArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ppa.setPositionPantalonList(position);
                ppa.setTipo(1);
                Intent intent = new Intent(getApplicationContext(), VerFotoActivity.class);
                startActivityForResult(intent, 10);
            }
        });
    }
    public void sincronizarSudaderasDatabase(View view){
        borrarRepetidos();
        ppa.listaSudaderas.clear();
        ParseQuery<Sudadera> query = ParseQuery.getQuery("Sudadera");
        query.findInBackground(new FindCallback<Sudadera>() {
            @Override
            public void done(List<Sudadera> objects, ParseException e) {
                if (e == null){
                    for (Sudadera sudadera : objects){
                        sudadera.getBBDD();
                        ppa.listaSudaderas.add(sudadera);
                        sudaderasArrayAdapter.notifyDataSetChanged();
                    }
                }
                else{
                    Log.d("Error query, reason " +e.getMessage(), "Sincronización sudaderas");
                }
            }
        });
        trasladarALocal();
    }
    public void trasladarALocal(){
        for (Sudadera sudadera: ppa.listaSudaderas){
            PrendaVestir prendaVestir = new PrendaVestir();
            prendaVestir.setID(sudadera.getId());
            prendaVestir.setTalla(sudadera.getTalla());
            prendaVestir.setTipoPrenda(1);
            prendaVestir.setComodidad(sudadera.getComodidad());
            prendaVestir.asociarProveedores(ppa.proveedorMaterialTextilList);
            ppa.prendaVestirList.add(prendaVestir);
        }
    }
    public void borrarRepetidos(){
        int prendaVestirIndex = -1;
        for (Sudadera sudadera : ppa.listaSudaderas){
            for (PrendaVestir prendaVestir : ppa.prendaVestirList){
                if (prendaVestir.getID() == sudadera.getId()){
                    prendaVestirIndex = ppa.prendaVestirList.indexOf(prendaVestir);
                    break;
                }
            }
            if (prendaVestirIndex != -1)
                ppa.prendaVestirList.remove(prendaVestirIndex);
        }
    }

    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }
}