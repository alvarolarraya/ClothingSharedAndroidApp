package com.example.stockprototype;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.parse.ParseFile;

public class VerFotoActivity extends AppCompatActivity {
    private Bitmap foto;
    PrendaProveedoresPedidosApplication ppa;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_foto);
        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();
        int position = ppa.getPositionPantalonList();
        ImageView imageView = (ImageView) findViewById(R.id.imageViewPantalon);
        if (ppa.getTipo() == 0) {
            imageView.setImageBitmap(ppa.listaPantalones.get(position).getImageBitmap());
        }
        else {
            imageView.setImageBitmap(ppa.listaSudaderas.get(position).getImageBitmap());
            System.out.println(ppa.listaSudaderas.get(position).getImageBitmap());
        }
    }
    public void cancelar(View view) {
        Intent intent;
        if (ppa.getTipo()==0){
             intent = new Intent(getApplicationContext(), ListarPantalonesDatabaseActivity.class);
        }
        else{
             intent = new Intent(getApplicationContext(), ListarSudaderasDatabaseActivity.class);
        }
        startActivityForResult(intent, 2);
    }
}
