package com.example.stockprototype.Modelos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.parse.GetDataCallback;
import com.parse.ParseClassName;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@ParseClassName("Sudadera")
public class Sudadera extends ParseObject {
    private String id;
    private String nombre;
    private int talla;
    private String tallaLetra;
    private float comodidad;
    private String material;

    public Bitmap getImageBitmap() {
        return imageBitmap;
    }

    public void setImageBitmap(Bitmap imageBitmap) {
        this.imageBitmap = imageBitmap;
    }

    private Bitmap imageBitmap;

    public List<ProveedorMaterialTextil> listaProveedoresAsociados = new ArrayList<>();

    public Sudadera(){
        this.id = randomizeID();
    }
    public float getComodidad() {
        return comodidad;
    }

    public void setComodidad(float comodidad) {
        this.comodidad = comodidad;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTallaLetra() {
        return tallaLetra;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTalla() {
        return talla;
    }

    public void setTalla(int talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    public void getBBDD(){
        nombre = getString("nombre");
        tallaLetra = getString("talla");
        talla = asignarTalla(getString("talla"));
        comodidad = (float) getDouble("comodidad");
        material = getString("material");
        ParseFile imageParseFile = (ParseFile) get("imagen");
        imageParseFile.getDataInBackground(new GetDataCallback() {
            @Override
            public void done(byte[] data, ParseException e) {
                System.out.println("puta");
                imageBitmap = BitmapFactory.decodeByteArray(data,0,data.length);
            }
        });
    }
    public int asignarTalla(String talla){
        switch (talla){
            case "XXS":
                return 0;
            case "XS":
                return 1;
            case "S":
                return 2;
            case "M":
                return 3;
            case "L":
                return 4;
            case "XL":
                return 5;
            case "XXL":
                return 6;
        }
        return 0;
    }
    public String randomizeID(){
        int leftLimit = 48; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 10;
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int)
                    (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        return(generatedString);
    }

    public void asociarProveedores(List<ProveedorMaterialTextil> listaProveedores){
        if (!listaProveedoresAsociados.isEmpty())
            listaProveedoresAsociados.clear();
        int i = 0;
            while (listaProveedores.get(i).getMaterialTextil() != "Hilo" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
            while (listaProveedores.get(i).getMaterialTextil() != "Algodón" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
    }

    private String color;
    @Override
    public String toString() {
        return "ID: " + this.id +
                "\nNombre:" + this.getNombre()+"" +
                "\nTalla: "+this.getTallaLetra() +
                "\n Comodidad: "+this.getComodidad() +
                "\n Material: "+this.getMaterial();
    }
}
