package com.example.stockprototype.Modelos;

public class ProveedorMaterialTextil {
    private String nombre;
    private String CIF;
    private String direccion;
    private String materialTextil;
    public ProveedorMaterialTextil(){

    }
    public ProveedorMaterialTextil(String nombre, String CIF, String direccion, String materialTextil){
        this.nombre = nombre;
        this.CIF = CIF;
        this.direccion = direccion;
        this.materialTextil = materialTextil;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCIF() {
        return CIF;
    }

    public void setCIF(String CIF) {
        this.CIF = CIF;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }


    public String getMaterialTextil() {
        return materialTextil;
    }

    public void setMaterialTextil(String materialTextil) {
        this.materialTextil = materialTextil;
    }
    public String toString() {
        return this.getNombre()+"\nCIF: "+this.getCIF()+"\nDirección: " +this.getDireccion()+"" +
                "\nMaterial: "+this.getMaterialTextil();
    }
}
