package com.example.stockprototype.Modelos;

import java.util.Random;

public class PedidoMaterialTextil {
    // Cada vez que se añade una prenda, se genera un pedido.
    private String idPedido;
    private String idPrenda;
    private ProveedorMaterialTextil proveedorMaterialTextil;
    private String materialTextil;
    private int costePedido;
    public PedidoMaterialTextil(ProveedorMaterialTextil proveedor, String materialTextil,
                                String idPrenda){
        this.proveedorMaterialTextil = proveedor;
        this.materialTextil = materialTextil;
        this.costePedido = randomizeCost();
        this.idPrenda = idPrenda;
        this.idPedido = randomizeID();
    }
    public int randomizeCost(){
        int a = (int) (Math.round(Math.random()*(10)+1));
        return a;
    }
    public String randomizeID(){
        int leftLimit = 48; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 10;
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int)
                    (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        return(generatedString);
    }

    public String getIdPedido() {
        return idPedido;
    }

    public String getIdPrenda() {
        return idPrenda;
    }

    public void setIdPrenda(String idPrenda) {
        this.idPrenda = idPrenda;
    }

    @Override
    public String toString() {
        return "ID Pedido: " + idPedido + "\nMaterial: " + materialTextil + "\nProveedor: "
                + proveedorMaterialTextil.getNombre() + "\nCoste: " + costePedido + "€";
    }
}
