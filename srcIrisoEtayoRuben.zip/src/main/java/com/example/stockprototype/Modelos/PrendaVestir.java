package com.example.stockprototype.Modelos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class PrendaVestir {
    private int tipoPrenda = 0;
    private String ID;
    private int talla = 0;
    private float comodidad;
    private HashMap<Integer, String> hashMapTallas = new HashMap<Integer, String>();
    private HashMap<Integer, String> hashMapTipoPrenda = new HashMap<Integer, String>();
    public List<ProveedorMaterialTextil> listaProveedoresAsociados = new ArrayList<>();

    public PrendaVestir(){
        rellenarHashMaps();
    }


    public String getTipoPrendaLetra() {
        return hashMapTipoPrenda.get(tipoPrenda);
    }
    public int getTipoPrenda() {
        return tipoPrenda;
    }

    public void setComodidad(float comodidad) {
        this.comodidad = comodidad;
    }

    public void setTipoPrenda(int tipoPrenda) {
        this.tipoPrenda = tipoPrenda;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public int getTalla() {
        return talla;
    }

    public String getTallaLetra(){
        return hashMapTallas.get(talla);
    }
    public void setTalla(int talla) {
        this.talla = talla;
    }

    public String randomizeID(){
        int leftLimit = 48; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 10;
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int)
                    (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        String generatedString = buffer.toString();

        return(generatedString);
    }
    public void rellenarHashMaps(){
        hashMapTipoPrenda.put(0, "Pantalón");
        hashMapTipoPrenda.put(1, "Sudadera");
        hashMapTallas.put(0, "XXS");
        hashMapTallas.put(1, "XS");
        hashMapTallas.put(2, "S");
        hashMapTallas.put(3, "M");
        hashMapTallas.put(4, "L");
        hashMapTallas.put(5, "XL");
        hashMapTallas.put(6, "XXL");
    }

    public float getComodidad() {
        return comodidad;
    }

    public void asociarProveedores(List<ProveedorMaterialTextil> listaProveedores){
        if (!listaProveedoresAsociados.isEmpty())
            listaProveedoresAsociados.clear();
        if (this.getTipoPrendaLetra() == "Pantalón"){
            int i = 0;
            while (listaProveedores.get(i).getMaterialTextil() != "Hilo" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
            while (listaProveedores.get(i).getMaterialTextil() != "Algodón" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
            while (listaProveedores.get(i).getMaterialTextil() != "Botones" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
        }
        else if (this.getTipoPrendaLetra() == "Sudadera"){
            int i = 0;
            while (listaProveedores.get(i).getMaterialTextil() != "Hilo" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
            while (listaProveedores.get(i).getMaterialTextil() != "Algodón" && i < listaProveedores.size()){
                i++;
            }
            listaProveedoresAsociados.add(listaProveedores.get(i));
        }
    }
    public List<ProveedorMaterialTextil> getListaProveedoresAsociados() {
        return listaProveedoresAsociados;
    }

    @Override
    public String toString() {
        return this.getID()+"\nTipo: "+this.getTipoPrendaLetra()+"\nTalla: "+this.getTallaLetra()
                +"\nComodidad: "+this.getComodidad();
    }
}
