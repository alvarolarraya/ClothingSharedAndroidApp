package com.example.stockprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.stockprototype.Modelos.PrendaVestir;

public class ModificarPrendaActivity extends AppCompatActivity {
    PrendaProveedoresPedidosApplication ppa;
    Spinner spinnerPrendas;
    Spinner spinnerTallas;
    private int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_prenda);
        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();
        spinnerPrendas= (Spinner) findViewById(R.id.spinner_prendas);
        ArrayAdapter<CharSequence> adapterPrendas=ArrayAdapter.createFromResource(this,
                R.array.string_array_prendas, android.R.layout.simple_spinner_item);
        adapterPrendas.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerPrendas.setAdapter(adapterPrendas);
        spinnerPrendas.setSelection((int)ppa.prendaVestirList.get(position).getTipoPrenda());

        spinnerTallas = (Spinner)findViewById(R.id.spinner_tallas);
        ArrayAdapter<CharSequence>adapterTallas=ArrayAdapter.createFromResource(this,
                R.array.string_array_tallas, android.R.layout.simple_spinner_item);
        adapterTallas.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerTallas.setAdapter(adapterTallas);
        spinnerTallas.setSelection((int)ppa.prendaVestirList.get(position).getTalla());

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();
        position = ppa.getPositionPrendaVestirList();
        TextView id = (TextView) findViewById(R.id.idPrenda);
        id.setText(ppa.prendaVestirList.get(position).getID());
    }
    public void modificarPrenda(View view){
        Intent intent = new Intent(getApplicationContext(), ListadoPrendasActivity.class);
        PrendaVestir prenda = new PrendaVestir();
        prenda.setTipoPrenda(spinnerPrendas.getSelectedItemPosition());
        prenda.setID(ppa.prendaVestirList.get(position).getID());
        prenda.setTalla(spinnerTallas.getSelectedItemPosition());
        ppa.modifyPrendaVestirList(position, prenda);
        startActivityForResult(intent, 1);
    }
    public void verProveedores(View view){
        Intent intent = new Intent(getApplicationContext(), ProveedoresAsociadosAPrendaActivity.class);
        startActivityForResult(intent, 1);
    }
    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), ListadoPrendasActivity.class);
        startActivityForResult(intent, 2);
    }
}