package com.example.stockprototype;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.stockprototype.Modelos.ProveedorMaterialTextil;
import com.example.stockprototype.databinding.ActivityListadoProveedoresBinding;

public class ListadoProveedoresActivity extends AppCompatActivity {

    private ActivityListadoProveedoresBinding binding;
    private PrendaProveedoresPedidosApplication ppa;
    ListView listView;
    ArrayAdapter<ProveedorMaterialTextil> proveedoresArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityListadoProveedoresBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();

        listView = findViewById(R.id.listaProveedores);
        proveedoresArrayAdapter = new ArrayAdapter<>(this, R.layout.item_view, R.id.listText, ppa.proveedorMaterialTextilList);

        listView.setAdapter(proveedoresArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ppa.setPositionProveedorMaterialTextilList(position);
                Intent intent = new Intent(getApplicationContext(), ModificarProveedorActivity.class);
                startActivityForResult(intent, 10);
            }
        });
    }
    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }
}