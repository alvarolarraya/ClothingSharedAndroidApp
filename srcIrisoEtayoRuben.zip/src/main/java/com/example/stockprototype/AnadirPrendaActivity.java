package com.example.stockprototype;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.stockprototype.Modelos.PrendaVestir;

public class AnadirPrendaActivity extends Activity {
    PrendaVestir prendaVestir = new PrendaVestir();
    Spinner spinnerPrendas;
    Spinner spinnerTallas;
    TextView id;
    PrendaProveedoresPedidosApplication ppa;
    PrendaVestir prenda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prenda = new PrendaVestir();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir_prenda);

        spinnerPrendas= (Spinner) findViewById(R.id.spinner_prendas);
        ArrayAdapter<CharSequence>adapterPrendas=ArrayAdapter.createFromResource(this, R.array.string_array_prendas, android.R.layout.simple_spinner_item);
        adapterPrendas.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerPrendas.setAdapter(adapterPrendas);

        spinnerTallas = (Spinner)findViewById(R.id.spinner_tallas);
        ArrayAdapter<CharSequence>adapterTallas=ArrayAdapter.createFromResource(this, R.array.string_array_tallas, android.R.layout.simple_spinner_item);
        adapterTallas.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerTallas.setAdapter(adapterTallas);

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();
        id = (TextView) findViewById(R.id.idPrenda);
        id.setText(prenda.randomizeID());
    }

    public void anadirPrenda(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        prenda.setTipoPrenda(spinnerPrendas.getSelectedItemPosition());
        prenda.setID((String) id.getText());
        prenda.setTalla(spinnerTallas.getSelectedItemPosition());
        prenda.asociarProveedores(ppa.proveedorMaterialTextilList);
        ppa.addPrendaVestir(prenda);
        ppa.crearPedidos(prenda);
        startActivityForResult(intent, 1);
    }
    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }

}