package com.example.stockprototype;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.stockprototype.Modelos.Pantalon;
import com.example.stockprototype.Modelos.PrendaVestir;
import com.example.stockprototype.databinding.ActivityListarPantalonesDatabaseBinding;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.List;

public class ListarPantalonesDatabaseActivity extends AppCompatActivity {

    private ActivityListarPantalonesDatabaseBinding binding;
    private PrendaProveedoresPedidosApplication ppa;
    ListView listView;
    ArrayAdapter<Pantalon> pantalonArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityListarPantalonesDatabaseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();

        listView = findViewById(R.id.listaPantalonesDatabase);
        pantalonArrayAdapter = new ArrayAdapter<Pantalon>(this, R.layout.item_view_ver_foto, R.id.listText, ppa.listaPantalones);

        listView.setAdapter(pantalonArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ppa.setPositionPantalonList(position);
                ppa.setTipo(0);
                Intent intent = new Intent(getApplicationContext(), VerFotoActivity.class);
                startActivityForResult(intent, 10);
            }
        });
    }
    public void sincronizarPantalonesDatabase(View view){
        borrarRepetidos();
        ppa.listaPantalones.clear();
        ParseQuery<Pantalon> query = ParseQuery.getQuery("Pantalon");
        query.findInBackground(new FindCallback<Pantalon>() {
            @Override
            public void done(List<Pantalon> objects, ParseException e) {
                if (e == null){
                    for (Pantalon pantalon : objects){
                        pantalon.getBBDD();
                        ppa.listaPantalones.add(pantalon);
                    }
                    pantalonArrayAdapter.notifyDataSetChanged();
                    trasladarALocal();
                }
                else{
                    Log.d("Error query, reason " +e.getMessage(), "Sincronización pantalones");
                }
            }
        });
    }
    public void trasladarALocal(){
        for (Pantalon pantalon: ppa.listaPantalones){
            PrendaVestir prendaVestir = new PrendaVestir();
            prendaVestir.setID(pantalon.getId());
            prendaVestir.setTalla(pantalon.getTalla());
            prendaVestir.setTipoPrenda(0);
            prendaVestir.setComodidad(pantalon.getComodidad());
            prendaVestir.asociarProveedores(ppa.proveedorMaterialTextilList);
            ppa.prendaVestirList.add(prendaVestir);
        }
    }
    public void borrarRepetidos(){
        int prendaVestirIndex = -1;
        for (Pantalon pantalon : ppa.listaPantalones){
            for (PrendaVestir prendaVestir : ppa.prendaVestirList){
                if (prendaVestir.getID() == pantalon.getId()){
                    prendaVestirIndex = ppa.prendaVestirList.indexOf(prendaVestir);
                    break;
                }
            }
            if (prendaVestirIndex != -1) {
                ppa.prendaVestirList.remove(prendaVestirIndex);
            }
        }
    }

    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }
}