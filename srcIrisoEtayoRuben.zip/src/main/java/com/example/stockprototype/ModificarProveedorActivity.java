package com.example.stockprototype;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.stockprototype.Modelos.ProveedorMaterialTextil;

public class ModificarProveedorActivity extends Activity {
    Spinner spinnerMateriales;
    Spinner spinnerTallas;
    PrendaProveedoresPedidosApplication ppa;
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_proveedor);
        spinnerMateriales = (Spinner) findViewById(R.id.spinner_materiales);
        ArrayAdapter<CharSequence>adapterPrendas=ArrayAdapter.createFromResource(this, R.array.string_array_materiales, android.R.layout.simple_spinner_item);
        adapterPrendas.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerMateriales.setAdapter(adapterPrendas);


        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();
        position = ppa.getPositionProveedorMaterialTextilList();
        TextView cif = (TextView) findViewById(R.id.cifProveedor);
        cif.setText(ppa.proveedorMaterialTextilList.get(position).getCIF());
        TextView nombreProveedor = (TextView) findViewById(R.id.nombreProveedor);
        nombreProveedor.setText(ppa.proveedorMaterialTextilList.get(position).getNombre());
        TextView direccionProveedor = (TextView) findViewById(R.id.direccionProveedor);
        direccionProveedor.setText(ppa.proveedorMaterialTextilList.get(position).getDireccion());
    }

    public void modificarProveedor(View view) {
        System.out.println(ppa.proveedorMaterialTextilList.size());

        Intent intent = new Intent(getApplicationContext(), ListadoProveedoresActivity.class);
        ProveedorMaterialTextil proveedorMaterialTextil = new ProveedorMaterialTextil();
        proveedorMaterialTextil.setMaterialTextil(spinnerMateriales.getSelectedItem().toString());
        String cif = ((TextView) findViewById(R.id.cifProveedor)).getText().toString();
        proveedorMaterialTextil.setCIF(cif);

        String direccion = ((TextView) findViewById(R.id.direccionProveedor)).getText().toString();
        proveedorMaterialTextil.setDireccion(direccion);

        String nombre = ((TextView) findViewById(R.id.nombreProveedor)).getText().toString();
        proveedorMaterialTextil.setNombre(nombre);

        ppa.modifyProveedorMaterialTextilList(position, proveedorMaterialTextil);
        startActivityForResult(intent, 1);
    }
    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }

}