package com.example.stockprototype;

import android.content.Intent;
import android.os.Bundle;

import com.example.stockprototype.Modelos.PrendaVestir;
import com.example.stockprototype.databinding.ActivityListadoPrendasBinding;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListadoPrendasActivity extends AppCompatActivity {

    private ActivityListadoPrendasBinding binding;
    private PrendaProveedoresPedidosApplication ppa;
    ListView listView;
    ArrayAdapter<PrendaVestir> prendaVestirArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityListadoPrendasBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();

        listView = findViewById(R.id.listaPrendas);
        prendaVestirArrayAdapter = new ArrayAdapter<PrendaVestir>(this, R.layout.item_view, R.id.listText, ppa.prendaVestirList);

        listView.setAdapter(prendaVestirArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ppa.setPositionPrendaVestirList(position);
                Intent intent = new Intent(getApplicationContext(), ModificarPrendaActivity.class);
                startActivityForResult(intent, 10);
            }
        });
    }
    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }

}