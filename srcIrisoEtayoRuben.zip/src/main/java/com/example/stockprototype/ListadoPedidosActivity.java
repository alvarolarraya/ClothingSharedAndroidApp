package com.example.stockprototype;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.stockprototype.Modelos.PedidoMaterialTextil;
import com.example.stockprototype.databinding.ActivityListadoPedidosBinding;

public class ListadoPedidosActivity extends AppCompatActivity {

    private ActivityListadoPedidosBinding binding;
    private PrendaProveedoresPedidosApplication ppa;
    ListView listView;
    ArrayAdapter<PedidoMaterialTextil> pedidosArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityListadoPedidosBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ppa = (PrendaProveedoresPedidosApplication) getApplicationContext();

        listView = findViewById(R.id.listaPedidos);
        pedidosArrayAdapter = new ArrayAdapter<PedidoMaterialTextil>(this, R.layout.item_view, R.id.listText, ppa.pedidoMaterialTextilList);

        listView.setAdapter(pedidosArrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ppa.setPositionProveedorMaterialTextilList(position);
                Intent intent = new Intent(getApplicationContext(), ModificarPrendaActivity.class);
                startActivityForResult(intent, 10);
            }
        });
    }
    public void cancelar(View view) {
        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
        startActivityForResult(intent, 2);
    }
}