package com.example.diversificacionpantalones;

import android.app.Application;
import android.content.Intent;

import com.example.diversificacionpantalones.Modelos.LotePantalones;
import com.example.diversificacionpantalones.Modelos.Pantalon;
import com.example.diversificacionpantalones.Modelos.Tela;
import com.parse.Parse;
import com.parse.ParseObject;

import java.util.ArrayList;
import java.util.List;

public class Controlador extends Application {

    public LotePantalones lotePantalones = new LotePantalones();
    public ArrayList<Tela> telas= new ArrayList<>();
    public ArrayList<String> nombresTelas = new ArrayList<>();
    AdaptadorListaPantalones adapterPantalones;
    AdaptadorListaTejidos adapterTejidos;
    public int posicion = -1;

    @Override
    public void onCreate() {
        super.onCreate();
        ParseObject.registerSubclass(Pantalon.class);
        ParseObject.registerSubclass(Tela.class);

        aniadirTela("por defecto");
        aniadirTela("algodon");
        aniadirTela("cuero");
        aniadirTela("nailon");
        aniadirTela("lana");
        aniadirTela("lino");


        Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId("myAppId") //si no has cambiado APP_ID, sino pon el valor de APP_ID
                .clientKey("empty")
                .server("https://alvarolarraya.herokuapp.com/parse")   // '/' important after 'parse'
                .build());
    }


    public void modificarDisenio(int posicion){
        this.posicion = posicion;
        Intent intent = new Intent(this,ConfigurarDisenio.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public void aniadirTela(String nombre){
        this.telas.add(new Tela(nombre, getResources().getIdentifier(nombre, "drawable", getPackageName())));
        this.nombresTelas.add(nombre);
    }

    public void aniadirPantalon(Pantalon pantalon){
        this.lotePantalones.aniadirPantalon(pantalon);
    }
}