package com.example.diversificacionpantalones;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.View;
import android.widget.ListView;

import com.example.diversificacionpantalones.databinding.ActivityMenuTejidos2Binding;

public class MenuTejidos extends AppCompatActivity {
    Controlador controlador;
    private ActivityMenuTejidos2Binding binding;
    ListView lv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMenuTejidos2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);


        // Junto el adaptador, la listview y la lista de tejidos
        lv2 = findViewById(R.id.listView);
        controlador = (Controlador) getApplicationContext();
        controlador.adapterTejidos = new AdaptadorListaTejidos(this, controlador.telas, controlador);
        System.out.println(lv2);
        lv2.setAdapter(controlador.adapterTejidos);

        FloatingActionButton fab = binding.fab;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}