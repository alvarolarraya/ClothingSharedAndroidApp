package com.example.diversificacionpantalones;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.diversificacionpantalones.AdaptadorListaPantalones;
import com.example.diversificacionpantalones.Controlador;
import com.example.diversificacionpantalones.Modelos.Tela;
import com.example.diversificacionpantalones.R;

import java.util.ArrayList;

public class AdaptadorListaTejidos extends ArrayAdapter {
    Controlador controlador;
    private static ArrayList<Tela> listadoTejidos;
    private LayoutInflater l_Inflater;


    public AdaptadorListaTejidos(Context context, ArrayList<Tela> results, Controlador controlador) {
        super(context,0,results);
        listadoTejidos = results;
        l_Inflater = LayoutInflater.from(context);
        this.controlador = controlador;
    }

    public int getCount() {
        return listadoTejidos.size();
    }

    public Object getItem(int position) {
        return listadoTejidos.get(position);
    }

    public long getItemId(int position) {
        return position;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        convertView = l_Inflater.inflate(R.layout.vista_tejido_lista, null);
        holder = new ViewHolder();
        holder.nombre = convertView.findViewById(R.id.nombreDiseño);
        holder.imagenTela = (ImageView) convertView.findViewById(R.id.imagenTela);
        convertView.setTag(holder);
        holder.imagenTela.setImageResource(listadoTejidos.get(position).getImage());
        holder.nombre.setText(" << "+ listadoTejidos.get(position).getNombre() + " >> ");
        return convertView;
    }

    // holder view for views
    static class ViewHolder {
        ImageView imagenTela;
        TextView nombre;
    }
}
