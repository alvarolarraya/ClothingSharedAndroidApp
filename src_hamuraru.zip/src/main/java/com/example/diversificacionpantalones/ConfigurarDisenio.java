package com.example.diversificacionpantalones;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.Rating;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.example.diversificacionpantalones.Modelos.Pantalon;
import com.example.diversificacionpantalones.Modelos.Tela;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.SaveCallback;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class ConfigurarDisenio extends Activity {
    Pantalon pantalon = new Pantalon();
    String texto;
    EditText editText;
    ImageView imagenDiseno;
    ImageView imagenTejido;
    Button botonSiguiente;
    Button botonAnterior;
    Controlador controlador;
    TextView vistaTalla;
    TextView vistaCantidad;
    TextView vistaTejido;
    RatingBar comodidad;


    int resourceId ;
    int images[]={R.drawable.pantalon1,R.drawable.pantalon2,R.drawable.pantalon3,R.drawable.pantalon4,R.drawable.pantalon5,R.drawable.pantalon6,R.drawable.pantalon7};
    int NUMERO_IMAGENES = 7;
    int i = -1;

    final String[] tallas = {"por defecto", "S", "XS", "M", "L","XL","XXL"};
    final String[] cantidades = {"por defecto","10", "100", "200", "600", "1000"};

    Spinner spinnerTejido;
    Spinner spinnerTalla;
    Spinner spinnerCantidad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Resources resources = this.getResources();
        setContentView(R.layout.activity_configurar_diseno);
        controlador = (Controlador)getApplicationContext();

        comodidad = (RatingBar) findViewById(R.id.ratingBar);
        editText = (EditText) findViewById(R.id.nombre_diseño);
        botonSiguiente = (Button) findViewById(R.id.botonSiguiente);
        botonAnterior = (Button) findViewById(R.id.botonAnterior);
        imagenDiseno = (ImageView) findViewById(R.id.imageView);
        imagenTejido = (ImageView) findViewById(R.id.imageTejido);

        vistaTalla = (TextView) findViewById(R.id.vistaTalla);
        vistaCantidad = (TextView) findViewById(R.id.vistaCantidad);
        vistaTejido = (TextView)findViewById(R.id.vistaTejido);


        spinnerTejido = (Spinner) findViewById(R.id.spinner_textura);
        spinnerTalla = (Spinner) findViewById(R.id.spinner_talla);
        spinnerCantidad = (Spinner) findViewById(R.id.spinner_cantidad);

        ArrayAdapter<String> adapterTallas = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,tallas);
        ArrayAdapter<String> adapterCantidades = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,cantidades);
        ArrayAdapter<String> adapterTejidos = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,controlador.nombresTelas);

        adapterTallas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterCantidades.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterTejidos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerTejido.setAdapter(adapterTejidos);
        spinnerTalla.setAdapter(adapterTallas);
        spinnerCantidad.setAdapter(adapterCantidades);

        comodidad.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                pantalon.setComodidad(comodidad.getRating());
            }
        });

        spinnerTejido.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
                if (position != 0){
                    String tejido = spinnerTejido.getSelectedItem().toString();
                    Toast.makeText(getBaseContext(), tejido, Toast.LENGTH_SHORT).show();
                    vistaTejido.setText(tejido);
                    resourceId = getResources().getIdentifier(tejido, "drawable", getPackageName());
                    imagenTejido.setImageResource(resourceId);
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}

        });

        spinnerCantidad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
                if (position != 0) {
                    String cantidad = spinnerCantidad.getSelectedItem().toString();
                    Toast.makeText(getBaseContext(), cantidad, Toast.LENGTH_SHORT).show();
                    vistaCantidad.setText(cantidad);
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}

        });

        spinnerTalla.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
                if (position != 0) {
                    String talla = spinnerTalla.getSelectedItem().toString();
                    Toast.makeText(getBaseContext(), talla, Toast.LENGTH_SHORT).show();
                    vistaTalla.setText(talla);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}

        });

        if (controlador.posicion != -1){
            vistaTalla.setText(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getTalla());
            vistaCantidad.setText(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getCantidad());
            vistaTejido.setText(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getTejido().getNombre());
            editText.setText(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getNombre());
            imagenDiseno.setImageResource(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getImage());
            imagenTejido.setImageResource(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getTejido().getImage());
            comodidad.setRating(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getComodidad());
        }

    }


    public void siguienteImagen(View view){
        if (i+1 < NUMERO_IMAGENES) {
            i++;
            imagenDiseno.setImageResource(images[i]);
        }
    }

    public void anteriorImagen(View view){
        if (i-1 >= 0) {
            i--;
            imagenDiseno.setImageResource(images[i]);
        }
    }


    public void guardarDisenio(View view){

        texto = editText.getText().toString();

        if (texto.isEmpty()) {
            Toast errorToast = Toast.makeText(this, "Error, CAMPO DEL NOMBRE VACIO", Toast.LENGTH_SHORT);
            errorToast.show();
        }


        else {

            if ( i == -1)
                pantalon.setImage(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getImage());
            else
                pantalon.setImage(images[i]);

            if (controlador.posicion != -1)
                controlador.lotePantalones.getListaPantalones().remove(controlador.posicion);

            controlador.adapterPantalones.notifyDataSetChanged();
            pantalon.setCantidad((String) vistaCantidad.getText());
            pantalon.setTalla((String) vistaTalla.getText());
            resourceId = getResources().getIdentifier((String) vistaTejido.getText(), "drawable", getPackageName());
            Tela tela = new Tela((String) vistaTejido.getText(), resourceId);
            pantalon.setTejido(tela);
            pantalon.setEstado("( en desarrollo )");
            pantalon.setNombre(texto);
            controlador.aniadirPantalon(pantalon);
            controlador.posicion = -1;
            controlador.adapterPantalones.notifyDataSetChanged();
            finish();
        }
    }


    public void producir( View view){
        texto = editText.getText().toString();

        if (texto.isEmpty()) {
            Toast errorToast = Toast.makeText(this, "Error, CAMPO DEL NOMBRE VACIO", Toast.LENGTH_SHORT);
            errorToast.show();
        }


        else {
            if ( i == -1)
                pantalon.setImage(controlador.lotePantalones.getListaPantalones().get(controlador.posicion).getImage());
            else
            pantalon.setImage(images[i]);

            if (controlador.posicion != -1)
                controlador.lotePantalones.eliminarPantalon(controlador.posicion);

            controlador.adapterPantalones.notifyDataSetChanged();
            pantalon.setCantidad((String) vistaCantidad.getText());
            pantalon.setTalla((String) vistaTalla.getText());
            resourceId = getResources().getIdentifier((String) vistaTejido.getText(), "drawable", getPackageName());
            Tela tela = new Tela((String) vistaTejido.getText(), resourceId);
            pantalon.setTejido(tela);
            pantalon.setEstado("( en produccion )");
            pantalon.setNombre(texto);
            controlador.aniadirPantalon(pantalon);
            controlador.posicion = -1;
            controlador.adapterPantalones.notifyDataSetChanged();

            Bitmap myBitmap = BitmapFactory.decodeResource(getResources(), pantalon.getImage());
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            myBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] data = stream.toByteArray();
            ParseFile file = new ParseFile("pantalon.png",data);
            System.out.println(file);

            pantalon.setImagen2(file);
            pantalon.subirPantalon();
            pantalon.saveInBackground(new SaveCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Log.d("Pantalon subido", "newParseObject()");
                    } else {
                        Log.d("Error al subir pantalon"+ e.getMessage(), "newParseObject()");
                    }
                }
            });
            finish();
            System.out.println("Imagen tela pantalon Antes de BBDD : "+pantalon.getImage());
        }
    }

    public void finalizarActividad(View view){
        finish();
    }

}

