package com.example.diversificacionpantalones.Modelos;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class LotePantalones {
    public ArrayList<Pantalon> pantalones = new ArrayList<>();

    public void aniadirPantalon(Pantalon pantalon){
        pantalones.add(pantalon);
    }


    public ArrayList<Pantalon> getListaPantalones(){
        return this.pantalones;
    }

    public void eliminarPantalon(int posicion){
        this.pantalones.remove(posicion);
    }
}
