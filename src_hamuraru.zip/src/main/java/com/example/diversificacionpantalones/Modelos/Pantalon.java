package com.example.diversificacionpantalones.Modelos;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.Toast;

import com.example.diversificacionpantalones.R;
import com.parse.FindCallback;
import com.parse.GetDataCallback;
import com.parse.ParseClassName;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.SaveCallback;

import java.io.ByteArrayOutputStream;
import java.util.List;

@ParseClassName("Pantalon")
public class Pantalon extends ParseObject{

    private String nombre;
    private Tela tejido;
    private String cantidad;
    private String talla;
    private String estado;
    private int image;
    private ParseFile imagen2;
    private float comodidad;
    Bitmap imagen;


    public Pantalon(){
    }

    public void setImage(int imagen) {
        this.image = imagen;
    }

    public void setImagen2(ParseFile imagen2) {
        this.imagen2 = imagen2;
    }

    public void setComodidad(float comodidad) {
        this.comodidad = comodidad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public void setTejido(Tela tejido) {
this.tejido = tejido;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public void setEstado(String estado) {this.estado = estado;}

    public Tela getTejido(){return this.tejido;}

    public String getTalla(){ return this.talla;}

    public String getCantidad(){ return this.cantidad;}

    public float getComodidad(){ return this.comodidad;}

    public String getNombre() {
        return  this.nombre;
    }

    public void BBDD() {
        nombre = getString("nombre");
        cantidad = getString("cantidad");
        talla = getString("talla");
        estado = "( en produccion )";
        image = getInt("imagen_pantalon");
        comodidad = (float) getDouble("comodidad");
        tejido = (Tela) getParseObject("Tela");
        try {
            tejido.fetchIfNeeded();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        tejido.BBDD();
        ParseFile imagenParseFile = (ParseFile) get("imagen");
        imagenParseFile.getDataInBackground(new GetDataCallback() {
                                                @Override
                                                public void done(byte[] data, ParseException e) {
                                                    imagen = BitmapFactory.decodeByteArray(data, 0, data.length);
                                                    System.out.println(imagen);
                                                }
                                            }
        );
    }

    public void eliminarBBDD(){
        this.deleteInBackground();
    }

    public String getEstado() { return this.estado;}

    public void subirPantalon(){
        put("imagen",this.imagen2);
        put("nombre", this.nombre);
        put("talla", this.talla);
        put("cantidad",this.cantidad);
        put("imagen_pantalon", this.image);
        put("estado", this.estado);
        put("Tela", this.tejido);
        put("comodidad", this.comodidad);
        put("material", this.tejido.getNombre());

        this.tejido.subirTejido();
        this.tejido.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if (e == null) {
                    Log.d("Tela subida", "newParseObject()");
                } else {
                    Log.d("Error al subir tela "+ e.getMessage(), "newParseObject()");
                }
            }
        });
    }

    public int getImage() {
        return image;
    }

    @Override
    public String toString() {
        return this.getNombre();
    }
}
