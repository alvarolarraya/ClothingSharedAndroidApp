package com.example.diversificacionpantalones.Modelos;
import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Tela")
public class Tela extends ParseObject{
    String nombre;
    int image;

    public Tela(){}

    public Tela(String nombre, int image) {
        this.nombre = nombre;
        this.image = image;
    }

    public void subirTejido(){
        put("nombre_tela", this.nombre);
        put("imagen_tela", this.image);
    }

    public String getNombre(){
        return(this.nombre);
    }

    public int getImage(){
        return (this.image);
    }

    public void BBDD(){
        nombre = getString("nombre_tela");
        image = getInt("imagen_tela");
    }

}
