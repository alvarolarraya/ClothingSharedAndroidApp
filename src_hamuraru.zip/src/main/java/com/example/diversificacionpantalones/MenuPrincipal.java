package com.example.diversificacionpantalones;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.diversificacionpantalones.Modelos.Pantalon;
import com.example.diversificacionpantalones.databinding.ActivityScrollingBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class MenuPrincipal extends AppCompatActivity{

    Controlador controlador;
    private ActivityScrollingBinding binding;
    ListView lv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityScrollingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);


        // Junto el adaptador, la listview y la lista de pantalones
        lv1 = findViewById(R.id.listView);
        controlador = (Controlador)getApplicationContext();
        controlador.adapterPantalones = new AdaptadorListaPantalones(this, (ArrayList<Pantalon>) controlador.lotePantalones.getListaPantalones(), controlador);
        lv1.setAdapter(controlador.adapterPantalones);


        FloatingActionButton fab = binding.fab;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ConfigurarDisenio.class);
                startActivityForResult(intent,1);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {
            case R.id.crearDiseño:{
                Intent intent = new Intent(getApplicationContext(), ConfigurarDisenio.class);
                startActivityForResult(intent,1);
                break;
            }
            case R.id.importarDisenios:{
                obtenerPantalonesBBDD( );
                break;
            }
            case R.id.Facebook:{
                Toast.makeText(getBaseContext(), "Enlace copiado para Facebook", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.Instagram:{
                Toast.makeText(getBaseContext(), "Enlace copiado para Instagram", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.Telegram:{
                Toast.makeText(getBaseContext(), "Enlace copiado para Telegram", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.Whatsapp:{
                Toast.makeText(getBaseContext(), "Enlace copiado para Whatsapp", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.mostrarTejidos:{
                Intent intent = new Intent(getApplicationContext(), MenuTejidos.class);
                startActivityForResult(intent,1);
            }

        }
        return super.onOptionsItemSelected(item);
    }

    public void obtenerPantalonesBBDD( ){
        ParseQuery<Pantalon> query = ParseQuery.getQuery("Pantalon");
        query.findInBackground(new FindCallback<Pantalon>() {
            public void done(List<Pantalon> objects, ParseException e) {
                if (e == null) {
                    for (Pantalon pantalon : objects){
                        pantalon.BBDD();
                        controlador.aniadirPantalon(pantalon);
                        controlador.adapterPantalones.notifyDataSetChanged();
                    }
                    Log.d("query OK (Pantalon)", "getServerList()");
                } else {
                    Log.d("error query, reason: " + e.getMessage(), "getServerList()");

                }
            }
        });
    }

}

