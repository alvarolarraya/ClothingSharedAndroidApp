package com.example.diversificacionpantalones;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.diversificacionpantalones.Modelos.Pantalon;

public class AdaptadorListaPantalones extends ArrayAdapter {

    Controlador controladorMio;
    private static ArrayList<Pantalon> listadoPantalones;
    private LayoutInflater l_Inflater;

    public AdaptadorListaPantalones(Context context, ArrayList<Pantalon> results, Controlador controlador) {
        super(context,0,results);
        listadoPantalones = results;
        l_Inflater = LayoutInflater.from(context);
        controladorMio = controlador;
    }

    public int getCount() {
        return listadoPantalones.size();
    }

    public Object getItem(int position) {
        return listadoPantalones.get(position);
    }

    public long getItemId(int position) {
        return position;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        convertView = l_Inflater.inflate(R.layout.vista_pantalon_lista, null);
        holder = new ViewHolder();
        holder.imagenPantalon = (ImageView) convertView.findViewById(R.id.imagenTela);
        holder.nombre = convertView.findViewById(R.id.nombreDiseño);
        holder.talla = convertView.findViewById(R.id.tallaDiseño);
        holder.cantidad = (TextView) convertView.findViewById(R.id.cantidadDiseño);
        holder.comodidad = (TextView) convertView.findViewById(R.id.comodidad);
        holder.textura = (TextView) convertView.findViewById(R.id.texturaDiseño);
        holder.imagenTela = (ImageView) convertView.findViewById(R.id.imagenTejido);

        if (listadoPantalones.get(position).getEstado() == "( en desarrollo )") {

            holder.botonModificar = (Button) convertView.findViewById(R.id.botonModificar);
            holder.botonModificar.setVisibility(View.VISIBLE);
            holder.botonModificar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((ListView) parent).performItemClick(v, position, 0);
                    controladorMio.posicion = position;
                    controladorMio.modificarDisenio(position);
                }
            });
        }



        holder.botonEliminar = convertView.findViewById(R.id.eliminar_diseño);

        // Handler del boton de eliminar.
        holder.botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ListView) parent).performItemClick(v, position, 0);
                Pantalon pantalon = listadoPantalones.get(position);
                pantalon.eliminarBBDD();
                listadoPantalones.remove(position);
                notifyDataSetChanged();
            }
        });

        convertView.setTag(holder);

        // Le damos valor a cada elemento del holder.
        holder.imagenPantalon.setImageResource(listadoPantalones.get(position).getImage());
        holder.imagenTela.setImageResource(listadoPantalones.get(position).getTejido().getImage());

        holder.comodidad.setText("COMODIDAD: "+listadoPantalones.get(position).getComodidad());
        holder.nombre.setText("NOMBRE: " + listadoPantalones.get(position).getNombre() + "  ESTADO : " + listadoPantalones.get(position).getEstado());
        holder.talla.setText("TALLA: " + listadoPantalones.get(position).getTalla());
        holder.cantidad.setText("CANTIDAD: " + listadoPantalones.get(position).getCantidad());
        holder.textura.setText("TEJIDO: " + listadoPantalones.get(position).getTejido().getNombre());
        return convertView;
    }

    // holder view for views
    public static class ViewHolder {
        ImageView imagenPantalon;
        ImageView imagenTela;
        TextView nombre;
        TextView talla;
        TextView comodidad;
        TextView textura;
        TextView cantidad;
        Button botonEliminar;
        Button botonModificar;

    }

}