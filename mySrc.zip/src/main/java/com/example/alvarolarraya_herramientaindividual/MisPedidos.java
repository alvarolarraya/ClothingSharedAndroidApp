package com.example.alvarolarraya_herramientaindividual;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alvarolarraya_herramientaindividual.Modelos.Pedido;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class MisPedidos extends AppCompatActivity {

    ListView listView;
    public List<Pedido> contenidoLista;
    private AdaptadorPedido adaptador;
    HoodiesApplication aplicacion;
    TextView textView31;
    ImageView imagenCruz;
    ImageView imagenCaja;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_pedidos);
        listView = (ListView) findViewById(R.id.listaMisPedidos);
        aplicacion = (HoodiesApplication) getApplicationContext();
        textView31 = findViewById(R.id.textView31);
        imagenCruz = findViewById(R.id.imagenCruz);
        imagenCaja = findViewById(R.id.imagenCaja);
        if(aplicacion.pedidosRealizados.size() == 0){
            imagenCruz.setVisibility(View.VISIBLE);
            imagenCaja.setVisibility(View.VISIBLE);
            textView31.setVisibility(View.VISIBLE);
        }else{
            imagenCruz.setVisibility(View.INVISIBLE);
            imagenCaja.setVisibility(View.INVISIBLE);
            textView31.setVisibility(View.INVISIBLE);
        }
        contenidoLista = aplicacion.pedidosRealizados;
        adaptador = new AdaptadorPedido(aplicacion, (ArrayList<Pedido>) aplicacion.pedidosRealizados);
        listView.setAdapter(adaptador);
    }

    public void sincronizarPedidos(View view){
        ParseQuery<Pedido> query = ParseQuery.getQuery("Pedido");
        query.findInBackground(new FindCallback<Pedido>() {
            public void done(List<Pedido> objects, ParseException e) {
                if (e == null) {
                    aplicacion.pedidosRealizados.clear();
                    for(Pedido pedido : objects){
                        pedido.getBBDD();
                        aplicacion.pedidosRealizados.add(pedido);
                    }
                    if(objects.size() != 0){
                        imagenCruz.setVisibility(View.INVISIBLE);
                        imagenCaja.setVisibility(View.INVISIBLE);
                        textView31.setVisibility(View.INVISIBLE);
                    }
                    adaptador.notifyDataSetChanged();
                    Log.d("object query server:", "todoItemsAdapter= notifyDataSetChanged");
                    Log.d("query OK ", "pedidos sincronizados correctamente");
                } else {
                    Log.d("error query, reason: " + e.getMessage(), "sincronizacion de pedidos");
                    Toast.makeText(
                            getBaseContext(),
                            "getServerList(): error  query, reason: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void terminar(View view) {finish();}
}