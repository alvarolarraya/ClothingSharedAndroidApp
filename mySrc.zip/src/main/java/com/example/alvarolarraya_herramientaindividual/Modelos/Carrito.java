package com.example.alvarolarraya_herramientaindividual.Modelos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alvarolarraya_herramientaindividual.AdaptadorPedido;
import com.example.alvarolarraya_herramientaindividual.HoodiesApplication;
import com.example.alvarolarraya_herramientaindividual.Modelos.Pedido;
import com.example.alvarolarraya_herramientaindividual.R;
import com.parse.ParseException;
import com.parse.SaveCallback;

import java.util.ArrayList;
import java.util.List;

public class Carrito extends AppCompatActivity {

    ListView listView;
    public List<Pedido> contenidoLista;
    private AdaptadorPedido adaptador;
    HoodiesApplication aplicacion;
    TextView textView30;
    ImageView imagenCarritoVacio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);
        listView = (ListView) findViewById(R.id.listaCarrito);
        aplicacion = (HoodiesApplication) getApplicationContext();
        textView30 = findViewById(R.id.textView30);
        imagenCarritoVacio = findViewById(R.id.imagenCarritoVacio);
        if(aplicacion.carrito.size() == 0){
            imagenCarritoVacio.setVisibility(View.VISIBLE);
            textView30.setVisibility(View.VISIBLE);
        }else{
            imagenCarritoVacio.setVisibility(View.INVISIBLE);
            textView30.setVisibility(View.INVISIBLE);
        }
        contenidoLista = aplicacion.carrito;
        adaptador = new AdaptadorPedido(aplicacion, (ArrayList<Pedido>) aplicacion.carrito);
        listView.setAdapter(adaptador);
    }

    public void comprar(View view){
        for (Pedido pedido:aplicacion.carrito) {
            pedido.subirPedido();
            pedido.saveInBackground(new SaveCallback() {
                public void done(ParseException e) {
                    if (e == null) {
                        try {
                            aplicacion.pedidosRealizados.add(pedido.clone());
                        } catch (CloneNotSupportedException cloneNotSupportedException) {
                            cloneNotSupportedException.printStackTrace();
                        }
                        Log.d("object saved in server:", "newParseObject()");
                    } else {
                        Log.d("save failed, reason: "+ e.getMessage(), "newParseObject()");
                        Toast.makeText(
                                getBaseContext(),
                                "newParseObject(): Object save failed  to server, reason: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

            });
        }
        aplicacion.carrito.clear();
        Toast myToast = Toast.makeText(aplicacion, "Pedido efectuado", Toast.LENGTH_LONG);
        myToast.show();
        adaptador.notifyDataSetChanged();
        imagenCarritoVacio.setVisibility(View.VISIBLE);
        textView30.setVisibility(View.VISIBLE);
    }

    public void terminar(View view) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}