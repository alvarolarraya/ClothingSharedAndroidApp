package com.example.alvarolarraya_herramientaindividual.Modelos;

import com.parse.ParseClassName;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

@ParseClassName("Pedido")
public class Pedido extends ParseObject implements Cloneable{

    private Material material;
    private Proveedor proveedor;
    private boolean envioSemanal;
    private int cantidad;
    private int color;
    private int precio;

    public Pedido() {
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public boolean isEnvioSemanal() {
        return envioSemanal;
    }

    public void setEnvioSemanal(boolean envioSemanal) {
        this.envioSemanal = envioSemanal;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void subirPedido() {
        material.subirServidor();
        proveedor.subirServidor();
        put("envioSemanal",envioSemanal);
        put("cantidad",cantidad);
        put("color",color);
        put("precio",precio);
        put("material",material);
        put("proveedor",proveedor);
    }

    public void getBBDD() {
        material = (Material) getParseObject("material");
        proveedor = (Proveedor) getParseObject("proveedor");
        try {
            material.fetchIfNeeded();
            proveedor.fetchIfNeeded();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        envioSemanal = getBoolean("envioSemanal");
        cantidad = getInt("cantidad");
        color = getInt("color");
        precio = getInt("precio");
        material.getBBDD();
        proveedor.getBBDD();
    }

    @Override
    public Pedido clone() throws CloneNotSupportedException {
        Pedido nuevo= new Pedido();
        nuevo.setMaterial(this.getMaterial().clone());
        nuevo.setProveedor(this.getProveedor().clone());
        nuevo.setPrecio(this.getPrecio());
        nuevo.setColor(this.getColor());
        nuevo.setCantidad(this.getCantidad());
        nuevo.setEnvioSemanal(this.isEnvioSemanal());
        return nuevo;
    }
}
