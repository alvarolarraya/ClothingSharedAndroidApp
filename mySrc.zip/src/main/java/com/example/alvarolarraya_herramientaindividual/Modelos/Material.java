package com.example.alvarolarraya_herramientaindividual.Modelos;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Material")
public class Material extends ParseObject implements Cloneable{
    private int id;
    private int precio;
    private String nombre;
    private boolean impermeabilidad;
    //ponerlo con estrellas
    private int suavidad;


    public Material(int id) {
        this.id = id;
    }

    public Material() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isImpermeabilidad() {
        return impermeabilidad;
    }

    public int getSuavidad() {
        return suavidad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setImpermeabilidad(boolean impermeabilidad) {
        this.impermeabilidad = impermeabilidad;
    }

    public void setSuavidad(int suavidad) {
        this.suavidad = suavidad;
    }

    @Override
    public String toString() {
        return this.getNombre();
    }

    public void subirServidor(){
        put("precio",precio);
        put("nombre",nombre);
        put("impermeabilidad",impermeabilidad);
        put("suavidad",suavidad);
    }

    public void getBBDD(){
        precio = getInt("precio");
        nombre = getString("nombre");
        impermeabilidad = getBoolean("impermeabilidad");
        suavidad = getInt("suavidad");
    }

    @Override
    public Material clone() throws CloneNotSupportedException {
        Material nuevo= new Material(this.id);
        nuevo.setImpermeabilidad(this.isImpermeabilidad());
        nuevo.setNombre(this.getNombre());
        nuevo.setPrecio(this.getPrecio());
        nuevo.setSuavidad(this.getSuavidad());
        return nuevo;
    }
}
