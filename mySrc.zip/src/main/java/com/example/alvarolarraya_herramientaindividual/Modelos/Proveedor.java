package com.example.alvarolarraya_herramientaindividual.Modelos;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Proveedor")
public class Proveedor extends ParseObject implements Cloneable{

    private int id;
    private String nombre;
    private String apellido1 = "primer apellido";
    private String apellido2 = "segundo apellido";
    private String compania = "Proveedores SL";
    private String email = "correo@gmail.com";
    private String telefono = "616 616 616";

    public Proveedor(int id) {
        this.id = id;
        nombre = "nombre "+id;
    }

    public Proveedor() {}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCompania() {
        return compania;
    }

    public void setCompania(String compania) {
        this.compania = compania;
    }

    public void subirServidor(){
        put("nombre",nombre);
        put("apellido1",apellido1);
        put("apellido2",apellido2);
        put("compania",compania);
        put("email",email);
        put("telefono",telefono);
    }

    public void getBBDD() {
        nombre = getString("nombre");
        apellido1 = getString("apellido1");
        apellido2 = getString("apellido2");
        compania = getString("compania");
        telefono = getString("telefono");
        email = getString("email");
    }

    @Override
    public Proveedor clone() throws CloneNotSupportedException {
        Proveedor nuevo= new Proveedor(this.id);
        nuevo.setTelefono(this.getTelefono());
        nuevo.setCompania(this.getCompania());
        nuevo.setNombre(this.getNombre());
        nuevo.setEmail(this.getEmail());
        nuevo.setApellido1(this.getApellido1());
        nuevo.setApellido2(this.getApellido2());
        return nuevo;
    }
}
