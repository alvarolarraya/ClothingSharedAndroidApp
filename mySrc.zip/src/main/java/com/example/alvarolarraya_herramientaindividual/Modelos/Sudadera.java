package com.example.alvarolarraya_herramientaindividual.Modelos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.service.autofill.SaveCallback;
import android.widget.Toast;

import com.parse.GetDataCallback;
import com.parse.ParseClassName;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;

import java.io.ByteArrayOutputStream;

@ParseClassName("Sudadera")
public class Sudadera extends ParseObject {

    private int id;
    private String nombre;
    private String descripcion;
    private Bitmap imagenSudadera;
    private String talla;
    private float comodidad;
    private String material;


    public Sudadera(int id){
        this.id = id;
        nombre = "nombre "+id;
        descripcion = "descripcion";
    }

    public Sudadera(){}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Bitmap getImagenSudadera() { return imagenSudadera; }

    public void setImagenSudadera(Bitmap imagenSudadera) { this.imagenSudadera = imagenSudadera; }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public float getComodidad() {
        return comodidad;
    }

    public void setComodidad(float comodidad) {
        this.comodidad = comodidad;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void subirModelo() {
        put("nombre",nombre);
        put("talla",talla);
        put("material",material);
        put("comodidad",comodidad);
        put("descripcion",descripcion);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        imagenSudadera.compress(Bitmap.CompressFormat.PNG, 100, bos);// can use something 70 in case u want to compress the image

        byte[] scaledData = bos.toByteArray();

        // Save the scaled image to Parse
        ParseFile photoFile = new ParseFile("imagen.jpg", scaledData);
        put("imagen",photoFile);
    }

    public void getBBDD() {
        comodidad = (float) getDouble("comodidad");
        talla = getString("talla");
        material = getString("material");
        nombre = getString("nombre");
        descripcion = getString("descripcion");
    }
}
