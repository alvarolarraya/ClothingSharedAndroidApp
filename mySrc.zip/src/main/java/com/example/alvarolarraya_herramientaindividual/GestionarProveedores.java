package com.example.alvarolarraya_herramientaindividual;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.alvarolarraya_herramientaindividual.Modelos.Proveedor;
import com.example.alvarolarraya_herramientaindividual.Modelos.Sudadera;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.List;

public class GestionarProveedores extends AppCompatActivity {
    HoodiesApplication aplicacion;
    ListView listView;
    public List<Proveedor> contenidoLista;
    private AdaptadorListaProveedores adaptador;
    final int SHOW_SUBACTIVITY = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestionar_proveedores);
        listView = (ListView) findViewById(R.id.listaProveedores);
        aplicacion = (HoodiesApplication) getApplicationContext();
        contenidoLista = aplicacion.listaProveedores;
        adaptador = new AdaptadorListaProveedores(aplicacion);
        listView.setAdapter(adaptador);
        FloatingActionButton fab = findViewById(R.id.botonNuevoProveedor3);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putInt("position", position);
                Intent intent = new Intent(getApplicationContext(), ModificarProveedor.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Proveedor proveedor = new Proveedor(aplicacion.idProveedor);
                aplicacion.idProveedor = aplicacion.idProveedor+1;
                contenidoLista.add(proveedor);
                Bundle bundle = new Bundle();
                bundle.putInt("position", (contenidoLista.size()-1));
                Intent intent = new Intent(getApplicationContext(), ModificarProveedor.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == MainActivity.RESULT_OK) {
            adaptador.notifyDataSetChanged();
        }
    }

    public void terminar(View view) {
        finish();
    }
}