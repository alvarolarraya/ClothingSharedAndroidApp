package com.example.alvarolarraya_herramientaindividual;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import com.example.alvarolarraya_herramientaindividual.Modelos.Proveedor;

public class ModificarProveedor extends AppCompatActivity {

    int position;
    HoodiesApplication aplicacion;
    Proveedor proveedor;
    String name;
    String apellido1;
    String apellido2;
    String email;
    String empresa;
    String telefono;
    EditText edit_name;
    EditText edit_apellido1;
    EditText edit_apellido2;
    EditText edit_email;
    EditText edit_empresa;
    EditText edit_telefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_proveedor);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position= bundle.getInt("position");
        aplicacion = (HoodiesApplication)getApplicationContext();
        proveedor = aplicacion.listaProveedores.get(position);
        name = proveedor.getNombre();
        apellido1 = proveedor.getApellido1();
        apellido2 = proveedor.getApellido2();
        email = proveedor.getEmail();
        empresa = proveedor.getCompania();
        telefono = proveedor.getTelefono();
        edit_name =(findViewById(R.id.editNombreProveedor));
        edit_name.setText(name);
        edit_apellido1 =( findViewById(R.id.editApellido1Proveedor));
        edit_apellido1.setText(apellido1);
        edit_apellido2 =( findViewById(R.id.editApellido2Proveedor));
        edit_apellido2.setText(apellido2);
        edit_email =( findViewById(R.id.editEmailProveedor));
        edit_email.setText(email);
        edit_empresa =( findViewById(R.id.editEmpresaProveedor));
        edit_empresa.setText(empresa);
        edit_telefono =( findViewById(R.id.editTelefonoProveedor));
        edit_telefono.setText(telefono);
    }

    public void saveConfiguration(View view) {
        name = edit_name.getText().toString();
        apellido1 = edit_apellido1.getText().toString();
        apellido2 = edit_apellido2.getText().toString();
        email = edit_email.getText().toString();
        empresa = edit_empresa.getText().toString();
        telefono = edit_telefono.getText().toString();
        if(!name.matches("")) {
            proveedor.setNombre(name);
        }
        if(!apellido1.matches("")) {
            proveedor.setApellido1(apellido1);
        }
        if(!apellido2.matches("")) {
            proveedor.setApellido2(apellido2);
        }
        if(!email.matches("")) {
            proveedor.setEmail(email);
        }
        if(!empresa.matches("")) {
            proveedor.setCompania(empresa);
        }
        if(!telefono.matches("")) {
            proveedor.setTelefono(telefono);
        }
        aplicacion.listaProveedores.set(position, proveedor);
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    public void eliminarHoodie(View view) {
        aplicacion.listaProveedores.remove(position);
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    public void terminar(View view) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}