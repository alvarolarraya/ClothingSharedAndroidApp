package com.example.alvarolarraya_herramientaindividual;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alvarolarraya_herramientaindividual.Modelos.Sudadera;
import java.util.List;

public class AdaptadorListaSudaderas extends BaseAdapter {

    private HoodiesApplication aplicacion;
    private List<Sudadera> listaSudaderas;

    public AdaptadorListaSudaderas(HoodiesApplication aplicacion) {
        this.aplicacion = aplicacion;
        this.listaSudaderas = aplicacion.hoodieList;
    }

    @Override
    public int getCount() {
        return listaSudaderas.size();
    }

    @Override
    public Object getItem(int i) {
        return listaSudaderas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        Sudadera sudadera = (Sudadera) getItem(i);

        view = LayoutInflater.from(aplicacion).inflate(R.layout.elemento_lista_sudaderas,null);
        ImageView imagenSudadera = (ImageView) view.findViewById(R.id.imagenSudadera);
        TextView nombre = (TextView) view.findViewById(R.id.nombreSudadera);
        TextView descripcion = (TextView) view.findViewById(R.id.descripcion);

        imagenSudadera.setImageBitmap(sudadera.getImagenSudadera());
        nombre.setText(sudadera.getNombre());
        descripcion.setText(sudadera.getDescripcion());

        return view;
    }
}
