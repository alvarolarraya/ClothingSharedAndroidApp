package com.example.alvarolarraya_herramientaindividual;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.alvarolarraya_herramientaindividual.Modelos.Pedido;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorPedido extends BaseAdapter {

    private HoodiesApplication aplicacion;
    private List<Pedido> listaPedidos;

    public AdaptadorPedido(HoodiesApplication aplicacion, ArrayList<Pedido> listaPedidos) {
        this.aplicacion = aplicacion;
        this.listaPedidos = listaPedidos;
    }

    @Override
    public int getCount() {
        return listaPedidos.size();
    }

    @Override
    public Object getItem(int i) {
        return listaPedidos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        Pedido pedido = (Pedido) getItem(i);
        view = LayoutInflater.from(aplicacion).inflate(R.layout.elementos_pedido,null);
        TextView nombreProveedorPedido = view.findViewById(R.id.nombreProveedorPedido);
        TextView materialPedido = view.findViewById(R.id.materialPedido);
        TextView envioSemanalPedido = view.findViewById(R.id.envioSemanalPedido);
        TextView colorPedido = view.findViewById(R.id.colorPedido);
        TextView CantidadPedido = view.findViewById(R.id.CantidadPedido);
        TextView precioPedido = view.findViewById(R.id.precioPedido);

        nombreProveedorPedido.setText(pedido.getProveedor().getNombre());
        materialPedido.setText(pedido.getMaterial().getNombre());
        if(pedido.isEnvioSemanal()){
            envioSemanalPedido.setText("Si");
        }else{
            envioSemanalPedido.setText("No");
        }
        colorPedido.setBackgroundColor(pedido.getColor());
        CantidadPedido.setText(Integer.toString(pedido.getCantidad()));
        precioPedido.setText(Integer.toString(pedido.getPrecio()));

        return view;
    }
}
