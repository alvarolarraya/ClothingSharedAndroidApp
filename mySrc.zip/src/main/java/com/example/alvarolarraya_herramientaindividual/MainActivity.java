package com.example.alvarolarraya_herramientaindividual;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import com.example.alvarolarraya_herramientaindividual.Modelos.Sudadera;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;

import android.provider.MediaStore;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.alvarolarraya_herramientaindividual.databinding.ActivityMainBinding;
import com.parse.FindCallback;
import com.parse.GetDataCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseQuery;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    HoodiesApplication aplicacion;
    ListView listView;
    public List<Sudadera> contenidoLista;
    private AdaptadorListaSudaderas adaptador;
    final int SHOW_SUBACTIVITY = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        FloatingActionButton fab = findViewById(R.id.fab);
        listView = (ListView) findViewById(R.id.lista);
        aplicacion = (HoodiesApplication) getApplicationContext();
        contenidoLista = aplicacion.hoodieList;
        adaptador = new AdaptadorListaSudaderas(aplicacion);
        listView.setAdapter(adaptador);
        getSudaderas();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putInt("position", position);
                Intent intent = new Intent(getApplicationContext(), ModifyHoodie.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Sudadera sudadera = new Sudadera(aplicacion.idSudadera);
                aplicacion.idSudadera += 1;
                contenidoLista.add(sudadera);
                Bundle bundle = new Bundle();
                bundle.putInt("position", (contenidoLista.size()-1));
                Intent intent = new Intent(getApplicationContext(), ModifyHoodie.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == MainActivity.RESULT_OK) {
            adaptador.notifyDataSetChanged();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        for(int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SpannableString spanString = new SpannableString(menu.getItem(i).getTitle().toString());
            spanString.setSpan(new ForegroundColorSpan(Color.WHITE), 0,     spanString.length(), 0); //fix the color to white
            item.setTitle(spanString);
        }
        return true;
    }

    public void sincronizarSudaderas(View view){
        getSudaderas();
    }

    public void getSudaderas(){
        ParseQuery<Sudadera> query = ParseQuery.getQuery("Sudadera");
        query.findInBackground(new FindCallback<Sudadera>() {
            public void done(List<Sudadera> objects, ParseException e) {
                if (e == null) {
                    aplicacion.hoodieList.clear();
                    for(Sudadera sudadera : objects){
                        sudadera.getBBDD();
                        ParseFile file = (ParseFile) sudadera.get("imagen");
                        file.getDataInBackground(new GetDataCallback() {
                            @Override
                            public void done(byte[] data, ParseException e) {
                                sudadera.setImagenSudadera(BitmapFactory.decodeByteArray(data, 0, data.length));
                                aplicacion.hoodieList.add(sudadera);
                                adaptador.notifyDataSetChanged();
                            }
                        });
                    }
                    Log.d("object query server:", "todoItemsAdapter= notifyDataSetChanged");
                    Log.d("query OK ", "prototipos sincronizados correctamente");
                } else {
                    Log.d("error query, reason: " + e.getMessage(), "sincronizacion de prototipos");
                    Toast.makeText(
                            getBaseContext(),
                            "getServerList(): error  query, reason: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.comprar_materiales) {
            Intent intent = new Intent(getApplicationContext(), ComprarMateriales.class);
            startActivityForResult(intent, SHOW_SUBACTIVITY);
            return true;
        }

        if (id == R.id.gestionarProveedores) {
            Intent intent = new Intent(getApplicationContext(), GestionarProveedores.class);
            startActivityForResult(intent, SHOW_SUBACTIVITY);
            return true;
        }

        if (id == R.id.mis_pedidos) {
            Intent intent = new Intent(getApplicationContext(), MisPedidos.class);
            startActivityForResult(intent, SHOW_SUBACTIVITY);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}