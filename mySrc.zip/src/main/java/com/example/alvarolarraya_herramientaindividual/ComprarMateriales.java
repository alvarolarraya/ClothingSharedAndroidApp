package com.example.alvarolarraya_herramientaindividual;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.alvarolarraya_herramientaindividual.Modelos.Carrito;
import com.example.alvarolarraya_herramientaindividual.Modelos.Material;
import com.example.alvarolarraya_herramientaindividual.Modelos.Pedido;
import com.example.alvarolarraya_herramientaindividual.Modelos.Proveedor;

import yuku.ambilwarna.AmbilWarnaDialog;

public class ComprarMateriales extends AppCompatActivity {

    final int SHOW_SUBACTIVITY = 1;
    Switch switchEnvioSemanal;
    HoodiesApplication aplicacion;
    boolean envioSemanaSeleccionado;
    int cantidadSeleccionada;
    int colorSeleccionado;
    TextView mostrarColor;
    Material materialSeleccionado;
    Proveedor proveedorSeleccionado;
    ArrayAdapter<Material> adaptadorMateriales;
    ImageView notificacionCarrito;
    TextView numeroPedidosCarrito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comprar_materiales);
        aplicacion = (HoodiesApplication) getApplicationContext();
        notificacionCarrito = findViewById(R.id.notificacionCarrito);
        numeroPedidosCarrito = findViewById(R.id.numeroPedidosCarrito);
        if(aplicacion.carrito.size() != 0){
            notificacionCarrito.setVisibility(View.VISIBLE);
            numeroPedidosCarrito.setVisibility(View.VISIBLE);
            int numPedidos = aplicacion.carrito.size();
            numeroPedidosCarrito.setText(Integer.toString(numPedidos));
        }
        else{
            notificacionCarrito.setVisibility(View.INVISIBLE);
            numeroPedidosCarrito.setVisibility(View.INVISIBLE);
        }
        Spinner selectorProveedor = findViewById(R.id.spinner);
        selectorProveedor.setSelection(-1);
        AdaptadorListaProveedores adaptador = new AdaptadorListaProveedores(aplicacion);
        selectorProveedor.setAdapter(adaptador);
        NumberPicker selectorCantidad = findViewById(R.id.selectorCantidad);
        cantidadSeleccionada =1;
        selectorCantidad.setMinValue(1);
        selectorCantidad.setMaxValue(1000000);
        mostrarColor = findViewById(R.id.mostrarColor);
        colorSeleccionado = ((ColorDrawable) mostrarColor.getBackground()).getColor();
        Spinner selectorMaterial = findViewById(R.id.selectorMaterial);
        adaptadorMateriales = new ArrayAdapter<Material>(this,android.R.layout.simple_list_item_1, aplicacion.listaMateriales);
        selectorMaterial.setAdapter(adaptadorMateriales);
        materialSeleccionado = (Material) selectorMaterial.getSelectedItem();
        proveedorSeleccionado = (Proveedor) selectorProveedor.getSelectedItem();
        envioSemanaSeleccionado = false;
        switchEnvioSemanal = findViewById(R.id.switchEnvioSemanal);
        selectorCantidad.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                cantidadSeleccionada = i1;
            }
        });
        selectorMaterial.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                materialSeleccionado = (Material) selectorMaterial.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        selectorProveedor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                proveedorSeleccionado = (Proveedor) selectorProveedor.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        switchEnvioSemanal.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                envioSemanaSeleccionado = !envioSemanaSeleccionado;
                if(envioSemanaSeleccionado){
                    Toast myToast = Toast.makeText(aplicacion, "Este mismo pedido te llegara cada semana", Toast.LENGTH_LONG);
                    myToast.show();
                }else{
                    Toast myToast = Toast.makeText(aplicacion, "Envio semanal cancelado", Toast.LENGTH_LONG);
                    myToast.show();
                }
            }
        });
    }

    public void seleccionarColor(View view){
        AmbilWarnaDialog ventanaEscoger = new AmbilWarnaDialog(this, colorSeleccionado, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                colorSeleccionado = color;
                mostrarColor.setBackgroundColor(color);
            }
        });
        ventanaEscoger.show();
    }

    public void verCarrito(View view){
        Intent intent = new Intent(getApplicationContext(), Carrito.class);
        startActivityForResult(intent, SHOW_SUBACTIVITY);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == MainActivity.RESULT_OK) {
            Intent intent = new Intent(aplicacion,ComprarMateriales.class);
            startActivity(intent);
            finish();
        }
    }

    public void addToCart(View view){
        Pedido pedido = new Pedido();
        pedido.setMaterial(materialSeleccionado);
        pedido.setCantidad(cantidadSeleccionada);
        pedido.setPrecio(cantidadSeleccionada*materialSeleccionado.getPrecio());
        pedido.setProveedor(proveedorSeleccionado);
        pedido.setColor(colorSeleccionado);
        pedido.setEnvioSemanal(envioSemanaSeleccionado);
        aplicacion.carrito.add(pedido);
        notificacionCarrito.setVisibility(View.VISIBLE);
        numeroPedidosCarrito.setVisibility(View.VISIBLE);
        int numPedidos = Integer.parseInt((String) numeroPedidosCarrito.getText());
        numPedidos += 1;
        numeroPedidosCarrito.setText(Integer.toString(numPedidos));
        Toast myToast = Toast.makeText(aplicacion, "Añadido al carrito", Toast.LENGTH_LONG);
        myToast.show();
    }

    public void terminar(View view) {
        finish();
    }
}