package com.example.alvarolarraya_herramientaindividual;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.alvarolarraya_herramientaindividual.Modelos.Material;
import com.example.alvarolarraya_herramientaindividual.Modelos.Sudadera;
import com.parse.ParseException;
import com.parse.SaveCallback;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class ModifyHoodie extends AppCompatActivity {
    final String[] posiblesTallas = {"S","XS","M","L","XL","XXL"};
    int GALLERY_REQUEST = 1;
    int position;
    HoodiesApplication aplicacion;
    Sudadera sudadera;
    String name;
    String descripcion;
    Bitmap imagenSudadera;
    ImageView imageView;
    RatingBar estrellas;
    float comodidad;
    ArrayAdapter<String> adaptadorTallas;
    String talla;
    String material;
    ArrayAdapter<String> adaptadorMateriales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position= bundle.getInt("position");
        aplicacion = (HoodiesApplication)getApplicationContext();
        sudadera = aplicacion.hoodieList.get(position);
        name = sudadera.getNombre();
        descripcion = sudadera.getDescripcion();
        imagenSudadera = sudadera.getImagenSudadera();
        EditText edit_name =( findViewById(R.id.edit_name));
        edit_name.setText(name);
        EditText edit_descripcion =( findViewById(R.id.edit_descripcion));
        edit_descripcion.setText(descripcion);
        imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageBitmap(imagenSudadera);
        Spinner selectorTallas = findViewById(R.id.spinner4);
        adaptadorTallas = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,posiblesTallas);
        selectorTallas.setAdapter(adaptadorTallas);
        estrellas = findViewById(R.id.ratingBar2);
        estrellas.setRating(sudadera.getComodidad());
        comodidad = estrellas.getRating();
        selectorTallas.setSelection(Arrays.asList(posiblesTallas).indexOf(sudadera.getTalla()));
        talla = (String) selectorTallas.getSelectedItem();
        Spinner selectorMaterial = findViewById(R.id.spinner5);
        ArrayList<String> materiales = new ArrayList<>();
        for (Material objetoMaterial:aplicacion.listaMateriales){
            materiales.add(objetoMaterial.toString());
        }
        adaptadorMateriales = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, materiales);
        selectorMaterial.setAdapter(adaptadorMateriales);
        selectorMaterial.setSelection(materiales.indexOf(sudadera.getMaterial()));
        material = (String) selectorMaterial.getSelectedItem();
        estrellas.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                comodidad = v;
            }
        });
        selectorMaterial.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                material = (String) selectorMaterial.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        selectorTallas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                talla = (String) selectorTallas.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public void seleccionarFoto(View view){
        Intent photoPickerIntent = new Intent();
        photoPickerIntent.setType("image/*");
        photoPickerIntent.setAction(photoPickerIntent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(photoPickerIntent,"Title"), GALLERY_REQUEST);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == MainActivity.RESULT_OK) {
            Uri uri = data.getData();
            Bitmap imagenSudadera = null;
            try {
                imagenSudadera = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            sudadera.setImagenSudadera(imagenSudadera);
            ImageView imageView = (ImageView) findViewById(R.id.imageView);
            imageView.setImageBitmap(imagenSudadera);
        }
    }

    public void saveConfiguration(View view) {
        EditText editTextNombre = (EditText) findViewById(R.id.edit_name);
        EditText editTextDescripcion = (EditText) findViewById(R.id.edit_descripcion);
        name = editTextNombre.getText().toString();
        descripcion = editTextDescripcion.getText().toString();
        if(!name.matches("")) {
            sudadera.setNombre(name);
        }
        if(!descripcion.matches("")) {
            sudadera.setDescripcion(descripcion);
        }
        sudadera.setComodidad(comodidad);
        sudadera.setTalla(talla);
        sudadera.setMaterial(material);
        aplicacion.hoodieList.set(position, sudadera);
        sudadera.subirModelo();
        sudadera.saveInBackground(new SaveCallback() {
            public void done(ParseException e) {
                if (e == null) {
                    Toast.makeText(getBaseContext(),"Modelo guardado correctamente.", Toast.LENGTH_SHORT).show();
                    Log.d("object saved in server:", "newParseObject()");
                } else {
                    Log.d("save failed, reason: "+ e.getMessage(), "newParseObject()");
                    Toast.makeText(
                            getBaseContext(),
                            "newParseObject(): Object save failed  to server, reason: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

        });
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    public void eliminarHoodie(View view) {
        Sudadera sudadera = aplicacion.hoodieList.get(position);
        sudadera.deleteInBackground();
        aplicacion.hoodieList.remove(position);
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    public void terminar(View view) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}