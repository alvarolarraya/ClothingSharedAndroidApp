package com.example.alvarolarraya_herramientaindividual;

import android.app.Application;

import com.example.alvarolarraya_herramientaindividual.Modelos.Material;
import com.example.alvarolarraya_herramientaindividual.Modelos.Pedido;
import com.example.alvarolarraya_herramientaindividual.Modelos.Proveedor;
import com.example.alvarolarraya_herramientaindividual.Modelos.Sudadera;
import com.parse.Parse;
import com.parse.ParseObject;

import java.util.ArrayList;
import java.util.List;

public class HoodiesApplication extends Application  {
    public List<Sudadera> hoodieList = new ArrayList<>();
    public List<Proveedor> listaProveedores = new ArrayList<>();
    public List<Material> listaMateriales = new ArrayList<>();
    public List<Pedido> carrito = new ArrayList<>();
    public List<Pedido> pedidosRealizados = new ArrayList<>();
    public List<Sudadera> ventasRealizadas = new ArrayList<>();
    public int idProveedor;
    public int idSudadera;
    public int idMaterial;
    @Override
    public void onCreate() {
        super.onCreate();

        ParseObject.registerSubclass(Pedido.class);
        ParseObject.registerSubclass(Material.class);
        ParseObject.registerSubclass(Proveedor.class);
        ParseObject.registerSubclass(Sudadera.class);


        Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId("myAppId") //si no has cambiado APP_ID, sino pon el valor de APP_ID
                .clientKey("empty")
                .server("https://alvarolarraya.herokuapp.com/parse")   // '/' important after 'parse'
                .build());


        idProveedor = 1;
        idSudadera = 1;
        idMaterial = 1;
        inicializarListaProveedores(listaProveedores);
        inicializarListaMateriales(listaMateriales);
        carrito = new ArrayList<>();
        System.out.println(carrito.size());
    }

    public void inicializarListaProveedores(List<Proveedor> listaProveedores) {

        for(int i=0; i<5; i++){
            Proveedor proveedor = new Proveedor(idProveedor);
            idProveedor = idProveedor+1;
            listaProveedores.add(i,proveedor);
        }
    }

    public void inicializarListaMateriales(List<Material> listaMateriales) {
        Material material = new Material(idMaterial);
        material.setNombre("Nailon");
        material.setPrecio(10);
        material.setImpermeabilidad(true);
        material.setSuavidad(3);
        listaMateriales.add(material);

        material = new Material(idMaterial);
        material.setNombre("Poliester");
        material.setPrecio(7);
        material.setImpermeabilidad(false);
        material.setSuavidad(2);
        listaMateriales.add(material);

        material = new Material(idMaterial);
        material.setNombre("Polar");
        material.setPrecio(8);
        material.setImpermeabilidad(false);
        material.setSuavidad(4);
        listaMateriales.add(material);

        material = new Material(idMaterial);
        material.setNombre("Seda");
        material.setPrecio(11);
        material.setImpermeabilidad(false);
        material.setSuavidad(5);
        listaMateriales.add(material);
    }
}
