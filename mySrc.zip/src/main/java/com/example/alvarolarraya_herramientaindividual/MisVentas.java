package com.example.alvarolarraya_herramientaindividual;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.alvarolarraya_herramientaindividual.Modelos.Material;
import com.example.alvarolarraya_herramientaindividual.Modelos.Pedido;
import com.example.alvarolarraya_herramientaindividual.Modelos.Proveedor;
import com.example.alvarolarraya_herramientaindividual.Modelos.Sudadera;
import com.parse.ParseException;
import com.parse.SaveCallback;

public class MisVentas extends AppCompatActivity {

    HoodiesApplication aplicacion;
    ArrayAdapter<String> adaptadorTallas;
    String tallaSeleccionada;
    final String[] posiblesTallas = {"S","XS","M","L","XL","XXL"};
    Sudadera sudaderaSeleccionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_ventas);
        aplicacion = (HoodiesApplication) getApplicationContext();
        Spinner selectorTallas = findViewById(R.id.spinner3);
        adaptadorTallas = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,posiblesTallas);
        selectorTallas.setAdapter(adaptadorTallas);
        tallaSeleccionada = (String) selectorTallas.getSelectedItem();
        //int id = getResources().getIdentifier("spinner"+2, "id", aplicacion.getPackageName());
        //        Spinner selectorSudadera = findViewById(id);
        Spinner selectorSudadera = findViewById(R.id.spinner2);
        selectorSudadera.setSelection(-1);
        AdaptadorListaSudaderas adaptador = new AdaptadorListaSudaderas(aplicacion);
        selectorSudadera.setAdapter(adaptador);
        sudaderaSeleccionada = (Sudadera) selectorSudadera.getSelectedItem();
        selectorSudadera.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sudaderaSeleccionada = (Sudadera) selectorSudadera.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public void vender(View view){
        sudaderaSeleccionada.setTalla(tallaSeleccionada);
        sudaderaSeleccionada.subirModelo();
        sudaderaSeleccionada.saveInBackground(new SaveCallback() {
            public void done(ParseException e) {
                if (e == null) {
                    Toast.makeText(getBaseContext(),"Venta registrada correctamente.", Toast.LENGTH_SHORT).show();
                    Log.d("object saved in server:", "newParseObject()");
                } else {
                    Log.d("save failed, reason: "+ e.getMessage(), "newParseObject()");
                    Toast.makeText(
                            getBaseContext(),
                            "newParseObject(): Object save failed  to server, reason: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

        });
    }

    public void terminar(View view) {finish();}
}