package com.example.alvarolarraya_herramientaindividual;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.alvarolarraya_herramientaindividual.Modelos.Proveedor;
import java.util.List;

public class AdaptadorListaProveedores extends BaseAdapter {

    private HoodiesApplication aplicacion;
    private List<Proveedor> listaProveedores;

    public AdaptadorListaProveedores(HoodiesApplication aplicacion) {
        this.aplicacion = aplicacion;
        this.listaProveedores = aplicacion.listaProveedores;
    }

    @Override
    public int getCount() {
        return listaProveedores.size();
    }

    @Override
    public Object getItem(int i) {
        return listaProveedores.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        Proveedor proveedor = (Proveedor) getItem(i);

        view = LayoutInflater.from(aplicacion).inflate(R.layout.elemento_lista_proveedores,null);
        TextView nombre = (TextView) view.findViewById(R.id.textViewNombreProveedor);
        TextView compania = (TextView) view.findViewById(R.id.textViewCompaniaProveedor);
        TextView email = (TextView) view.findViewById(R.id.textViewCorreoProveedor);

        nombre.setText(proveedor.getNombre());
        compania.setText(proveedor.getCompania());
        email.setText(proveedor.getEmail());

        return view;
    }
}
